#include <iostream>
#include <vector>
#include <cctype>



using namespace std;

int main() {
    string palabra;
    int intentosRestantes;

    vector<string> palabras = {"programacion", "ahorcado", "calculadora", "cargador", "tierra", "casa", "gato","perro", "lampara", "puerta"};

    srand(time(0));
    string palabraSecreta = palabras[rand() % palabras.size()];

    string palabraElegida(palabraSecreta.size(), '_');
    vector<char> letrasUsadas;
    intentosRestantes = 6;

    cout << "Bienvenido al juego del Ahorcado" << endl;

      while (true) {
        if (intentosRestantes == 0 || palabraElegida == palabraSecreta) {
            break;
        }

        cout << "\nPalabra: ";
        for (size_t i = 0; i < palabraElegida.size(); i++) {
            if (intentosRestantes == 0 || palabraElegida == palabraSecreta) {
            }else cout << (char)toupper(palabraElegida[i]); 
        }
        cout << endl;
        cout << "Intentos restantes:" << intentosRestantes << endl;
        cout << "Letras usadas:";
          for (size_t i = 0; i < letrasUsadas.size(); i++) {
            cout << letrasUsadas[i] << " ";}
        cout << endl;

        cout << "Ingresa una letra: ";
        string entrada;
        cin >> entrada;
        
          if (entrada.size() != 1) {
            cout << "Error: solo puedes ingresar UNA letra a la vez." << endl;
            continue;
        }

          char letra = tolower(entrada[0]);
        
        if (!isalpha(letra)){
        cout << "Error solo se permiten letras intentalo de nuevo" << endl;
        continue;}
        
        bool usada = false;
         for (size_t i = 0; i < letrasUsadas.size(); i++) {
             if (letrasUsadas[i] == letra) {
                usada = true;
                break;
            }
        }

        if (usada) {
            cout << "Ya usaste esa letra. Intenta con otra." << endl;
            continue;
        }

        letrasUsadas.push_back(letra);

        bool acierto = false;
        for (size_t i = 0; i < palabraSecreta.size(); i++) {
            if (palabraSecreta[i] == letra) {
                palabraElegida[i] = letra;
                acierto = true;
            }
        }

        if (!acierto) {
            intentosRestantes--;
            cout << "Letra incorrecta!" << endl;
        } else {
            cout << "Bien! Encontraste una letra." << endl;
        }
    }

    if (palabraElegida == palabraSecreta) {
        cout << "¡Felicidades! Adivinaste la palabra: ";
        for (size_t i = 0; i < palabraSecreta.size(); i++) {
            cout << (char)toupper(palabraSecreta[i]);
        }
        cout << endl;
    } else {
        cout << "Perdiste. La palabra era: ";
        for (size_t i = 0; i < palabraSecreta.size(); i++) {
            cout << (char)toupper(palabraSecreta[i]);
        }
        cout << endl;
    }

  return 0;
}
